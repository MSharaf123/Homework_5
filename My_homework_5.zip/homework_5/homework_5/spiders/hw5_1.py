# -*- coding: utf-8 -*-
import scrapy


class Hw51Spider(scrapy.Spider):
    name = 'hw5_1'
    allowed_domains = ['stackoverflow.com']
    start_urls = ['https://stackoverflow.com/questions/tagged/python/?page=1&sort=newest&pageSize=50',
    'https://stackoverflow.com/questions/tagged/machine-learning?page=2&sort=newest&pagesize=50',
    'https://stackoverflow.com/questions/tagged/machine-learning?page=3&sort=newest&pagesize=50']


    def parse(self, response):
        f = response.css('div.summary')
        for j in f:
            yield {
                'Question': j.css('h3 a.question-hyperlink::text').extract_first(),
                'URL':'https://stackoverflow.com' + str(j.css('h3 a.question-hyperlink::attr(href)').extract_first())
                
            }    
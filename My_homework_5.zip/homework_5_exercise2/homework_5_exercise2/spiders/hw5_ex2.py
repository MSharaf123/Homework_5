# -*- coding: utf-8 -*-
import scrapy


class Hw5Ex2Spider(scrapy.Spider):
    name = 'hw5_ex2'
    allowed_domains = ['imdb.com']
    start_urls = ['http://www.imdb.com/chart/top']

    def parse(self, response):
        for j in response.css('tr')[1:-2]:
            yield{
        	    'Movie_Rank': j.css('td.titleColumn::text').re('[0-9]+')[0],
                'Title': j.css('td.titleColumn a::text').extract_first(),
                'URL': 'http://imdb.com' + str(j.css("td.titleColumn a::attr(href)").extract_first()),
                'Release_Year': j.css("span.secondaryInfo::text").extract_first(),
                'Rating': j.css('td strong::text').extract_first()  
        	}

        average =[]
        for f in response.css('tr')[1:-2]:
            rating=f.css('td strong::text').extract_first()
        a=float(rating)
        average.append(a)
        avg=sum(average)/len(average)
        yield{
        "Average":avg
        }


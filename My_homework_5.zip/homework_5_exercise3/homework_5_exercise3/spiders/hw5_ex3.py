# -*- coding: utf-8 -*-
import scrapy
import json

class Hw5Ex3Spider(scrapy.Spider):
    name = 'hw5_ex3'
    allowed_domains = ['imdb.com']
    start_urls = []

    with open ('C:\Users\Toshiba\Desktop\Data_Scraping2\homework_5_exercise2\homework_5_exercise2\spiders\hw5_exercise_2.json') as f: 
       	r = f.read()
    	url = json.loads(r)
    	for i in range(10):
    		start_urls.append(url[i]['URL'])

    def parse(self, response):
        yield{
        "Movie": response.xpath('//*[contains(@class, "title_wrapper")]/h1/text()').extract_first(),
        "director": response.xpath('//*[contains(@class, "credit_summary_item")]/span/a/span/text()').extract_first()
        }
 

